import fs from 'node:fs';

// Accès brut au fichier JSON qui sert de base de données.
const DB_FILE = process.env.DB_FILE ?? 'data/db.json';

export function lireDb(): any {
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
}

export function ecrireDb(db: any): void {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
