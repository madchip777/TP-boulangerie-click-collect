import { lireDb, ecrireDb } from './jsonDb';

export class JsonProduitRepository {
  tous(): any[] {
    return lireDb().produits;
  }

  trouverParId(id: string): any | undefined {
    return lireDb().produits.find((p: any) => p.id === id);
  }

  enregistrer(produit: any): void {
    const db = lireDb();
    db.produits = db.produits.map((p: any) => (p.id === produit.id ? produit : p));
    ecrireDb(db);
  }
}
